#!/usr/bin/env python3
"""Flask backend for Graha Computer Giveaway - auto-scrape IG/TikTok comments."""

import re
import json
import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── Serve frontend ───
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('.', filename)


# ─── Instagram comment scraper ───
def scrape_instagram(shortcode):
    """Scrape comments from Instagram post using GraphQL API."""
    comments = []
    seen = set()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'X-IG-App-ID': '936619743392459',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    try:
        # First get the post page to extract media_id
        url = f'https://www.instagram.com/p/{shortcode}/'
        resp = requests.get(url, headers=headers, timeout=15)
        
        # Extract media_id from page source
        media_id = None
        match = re.search(r'"media_id":"(\d+)"', resp.text)
        if match:
            media_id = match.group(1)
        
        if not media_id:
            # Try alternate method - look for shortcode_to_media_id
            match = re.search(r'"shortcode_media":\{"id":"(\d+)"', resp.text)
            if match:
                media_id = match.group(1)
        
        if not media_id:
            return scrape_instagram_fallback(shortcode)
        
        # Use GraphQL comments endpoint
        comments_url = 'https://www.instagram.com/graphql/query/'
        has_next = True
        cursor = None
        
        while has_next and len(comments) < 500:
            doc_id = '8845758582119845'  # CommentsQuery
            variables = {
                'media_id': media_id,
                'first': 50,
            }
            if cursor:
                variables['after'] = cursor
            
            resp = requests.get(
                comments_url,
                params={
                    'query_hash': '33ba35852cb50da46f5b5e889df7d159',
                    'variables': json.dumps(variables)
                },
                headers=headers,
                timeout=15
            )
            
            data = resp.json()
            if 'data' not in data:
                break
                
            media = data.get('data', {}).get('shortcode_media', {})
            if not media:
                media = data.get('data', {}).get('media', {})
            
            comment_edges = (media.get('edge_media_to_parent_comment', {}) or 
                           media.get('edge_media_preview_comment', {})).get('edges', [])
            
            for edge in comment_edges:
                node = edge.get('node', {})
                username = node.get('owner', {}).get('username', '')
                if username and username not in seen:
                    seen.add(username)
                    comments.append({
                        'username': username,
                        'text': node.get('text', ''),
                        'timestamp': node.get('created_at', 0)
                    })
            
            page_info = (media.get('edge_media_to_parent_comment', {}) or 
                        media.get('edge_media_preview_comment', {})).get('page_info', {})
            has_next = page_info.get('has_next_page', False)
            cursor = page_info.get('end_cursor')
            
            if not cursor:
                break
        
        # If no comments from GraphQL, try fallback
        if not comments:
            return scrape_instagram_fallback(shortcode)
            
    except Exception as e:
        print(f"IG GraphQL error: {e}")
        return scrape_instagram_fallback(shortcode)
    
    return comments


def scrape_instagram_fallback(shortcode):
    """Fallback: extract comments from page HTML."""
    comments = []
    seen = set()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    }
    
    try:
        url = f'https://www.instagram.com/p/{shortcode}/'
        resp = requests.get(url, headers=headers, timeout=15)
        
        # Try to find comments embedded in page
        # Look for patterns like "text":"..." and "username":"..."
        text_matches = re.findall(r'"text"\s*:\s*"([^"]{1,500})"', resp.text)
        user_matches = re.findall(r'"username"\s*:\s*"([a-zA-Z0-9_.]{1,30})"', resp.text)
        
        # Also try __a=1 API
        api_url = f'https://www.instagram.com/p/{shortcode}/?__a=1&__d=dis'
        try:
            api_resp = requests.get(api_url, headers={
                **headers,
                'X-IG-App-ID': '936619743392459',
            }, timeout=15)
            if api_resp.status_code == 200:
                data = api_resp.json()
                items = (data.get('graphql', {}).get('shortcode_media', {}) or 
                        data.get('items', [{}]))
                
                if isinstance(items, dict):
                    edge_comments = items.get('edge_media_to_parent_comment', {}).get('edges', [])
                    for edge in edge_comments:
                        node = edge.get('node', {})
                        username = node.get('owner', {}).get('username', '')
                        if username and username not in seen:
                            seen.add(username)
                            comments.append({
                                'username': username,
                                'text': node.get('text', ''),
                                'timestamp': node.get('created_at', 0)
                            })
        except:
            pass
        
        # If still no comments, extract from HTML
        if not comments:
            for user in user_matches:
                if user not in seen and user not in ['instagram', 'p', 'reel']:
                    seen.add(user)
                    comments.append({'username': user, 'text': '', 'timestamp': 0})
        
    except Exception as e:
        print(f"IG fallback error: {e}")
    
    return comments


# ─── TikTok comment scraper ───
def scrape_tiktok(video_id):
    """Scrape comments from TikTok video."""
    comments = []
    seen = set()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
        'Accept': 'application/json',
    }
    
    try:
        cursor = 0
        has_more = True
        
        while has_more and len(comments) < 500:
            url = f'https://www.tiktok.com/api/comment/list/?aweme_id={video_id}&cursor={cursor}&count=50'
            resp = requests.get(url, headers=headers, timeout=15)
            
            if resp.status_code != 200:
                break
            
            data = resp.json()
            comment_list = data.get('comments', [])
            
            if not comment_list:
                break
            
            for c in comment_list:
                user = c.get('user', {})
                username = user.get('unique_id', '') or user.get('nickname', '')
                if username and username not in seen:
                    seen.add(username)
                    comments.append({
                        'username': username,
                        'text': c.get('text', ''),
                        'timestamp': c.get('create_time', 0)
                    })
            
            has_more = data.get('has_more', 0) == 1
            cursor = data.get('cursor', 0)
            
            if not has_more:
                break
                
    except Exception as e:
        print(f"TikTok error: {e}")
    
    return comments


# ─── API Endpoints ───
@app.route('/api/scrape', methods=['POST'])
def api_scrape():
    """Scrape comments from a post URL."""
    data = request.json
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'error': 'URL tidak boleh kosong'}), 400
    
    # Detect platform and extract ID
    platform = None
    post_id = None
    
    # Instagram: /p/SHORTCODE/ or /reel/SHORTCODE/
    ig_match = re.search(r'instagram\.com/(?:p|reel|tv)/([a-zA-Z0-9_-]+)', url)
    if ig_match:
        platform = 'instagram'
        post_id = ig_match.group(1)
    
    # TikTok: /video/VIDEO_ID or vm.tiktok.com/SHORTCODE
    tk_match = re.search(r'tiktok\.com/@[^/]+/video/(\d+)', url)
    if tk_match:
        platform = 'tiktok'
        post_id = tk_match.group(1)
    
    if not tk_match:
        # Try short URL
        tk_short = re.search(r'vm\.tiktok\.com/([a-zA-Z0-9]+)', url)
        if tk_short:
            platform = 'tiktok'
            # Resolve short URL
            try:
                resp = requests.head(f'https://vm.tiktok.com/{tk_short.group(1)}/', 
                                   allow_redirects=True, timeout=10)
                tk_match2 = re.search(r'/video/(\d+)', resp.url)
                if tk_match2:
                    post_id = tk_match2.group(1)
            except:
                pass
    
    if not platform:
        return jsonify({'error': 'URL tidak valid. Gunakan link Instagram atau TikTok.'}), 400
    
    if not post_id:
        return jsonify({'error': 'Tidak bisa mengekstrak ID postingan. Coba link lain.'}), 400
    
    # Scrape comments
    try:
        if platform == 'instagram':
            comments = scrape_instagram(post_id)
        else:
            comments = scrape_tiktok(post_id)
        
        # Dedup by username
        seen = set()
        unique = []
        for c in comments:
            if c['username'].lower() not in seen:
                seen.add(c['username'].lower())
                unique.append(c)
        
        return jsonify({
            'success': True,
            'platform': platform,
            'post_id': post_id,
            'total_raw': len(comments),
            'total_unique': len(unique),
            'comments': unique
        })
        
    except Exception as e:
        return jsonify({'error': f'Gagal mengambil komentar: {str(e)}'}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)
